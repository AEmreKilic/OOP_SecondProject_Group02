package UI;

import data.Operations_onUser;
import data.Operations_onContact;
import person.User;

public class MenuManager
{
    private final Operations_onUser userOps;
    private final Operations_onContact contactOps;

    public MenuManager(Operations_onUser userOps, Operations_onContact contactOps)
    {
        this.userOps = userOps;
        this.contactOps = contactOps;
    }

    public void showMenuFor(User user)
    {
        if (user == null)
        {
            System.out.println("No user is logged in. Exiting.");
            return;
        }

        String role = user.getRole();

        if (role == null)
        {
            System.out.println("User role is undefined. Exiting.");
            return;
        }

        System.out.println("Opening menu for role: " + role);

        switch (role)
        {
            case "Tester":
                showTesterMenu(user);
                break;

            case "Junior Developer":
                showJuniorDeveloperMenu(user);
                break;

            case "Senior Developer":
                showSeniorDeveloperMenu(user);
                break;

            case "Manager":
                showManagerMenu(user);
                break;

            default:
                System.out.println("Unknown role: " + role + ". Exiting.");
                break;
        }
    }

    private void showTesterMenu(User user)
    {
        boolean running = true;

        while (running)
        {
            System.out.println();
            System.out.println("=== Tester Menu ===");
            System.out.println("Logged in as: " + user.getFullName() + " (role: " + user.getRole() + ")");
            System.out.println();
            System.out.println("0 - Logout");
            System.out.println("1 - Change password");
            System.out.println("2 - List all contacts");
            System.out.println("3 - Search contacts by a single field");
            System.out.println("4 - Search contacts by two fields");
            System.out.println("5 - Sort contacts");
            System.out.print("Select an option, only the number: ");

            String choice = Main.SC.nextLine().trim();

            switch (choice)
            {
                case "0":
                    System.out.println("Logging out. Goodbye, " + user.getFullName() + ".");
                    running = false;
                    break;

                case "1":
                    // User changes own password
                    userOps.changePassword(user.getUserId());
                    break;

                case "2":
                    // List all contacts with full details
                    contactOps.listAllContacts();
                    break;

                case "3":
                    // Single field search (field selected inside the function)
                    contactOps.searchSingleField();
                    break;

                case "4":
                    // Multiple fields search (predefined combos inside the function)
                    contactOps.searchMultipleFields();
                    break;

                case "5":
                    // Sort contacts (first name / nickname / birth date)
                    contactOps.sortContacts();
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }

    private void showJuniorDeveloperMenu(User user)
    {
        boolean running = true;

        while (running)
        {
            System.out.println();
            System.out.println("=== Junior Developer Menu ===");
            System.out.println("Logged in as: " + user.getFullName() + " (role: " + user.getRole() + ")");
            System.out.println();
            System.out.println("0 - Logout");
            System.out.println("1 - Change password");
            System.out.println("2 - List all contacts");
            System.out.println("3 - Search contacts by a single field");
            System.out.println("4 - Search contacts by two fields");
            System.out.println("5 - Sort contacts");
            System.out.println("6 - Update existing contact");
            System.out.print("Select an option,  only the number: ");

            String choice = Main.SC.nextLine().trim();

            switch (choice)
            {
                case "0":
                    System.out.println("Logging out. Goodbye, " + user.getFullName() + ".");
                    running = false;
                    break;

                case "1":
                    // User changes own password
                    userOps.changePassword(user.getUserId());
                    break;

                case "2":
                    // List all contacts with full details
                    contactOps.listAllContacts();
                    break;

                case "3":
                    // Single field search
                    contactOps.searchSingleField();
                    break;

                case "4":
                    // Multiple fields search
                    contactOps.searchMultipleFields();
                    break;

                case "5":
                    // Sort contacts
                    contactOps.sortContacts();
                    break;

                case "6":
                    // Update existing contact (one field)
                    contactOps.updateContactField();
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }

    private void showSeniorDeveloperMenu(User user)
    {
        boolean running = true;

        while (running)
        {
            System.out.println();
            System.out.println("=== Senior Developer Menu ===");
            System.out.println("Logged in as: " + user.getFullName() + " (role: " + user.getRole() + ")");
            System.out.println();
            System.out.println("0 - Logout");
            System.out.println("1 - Change password");
            System.out.println("2 - List all contacts");
            System.out.println("3 - Search contacts by a single field");
            System.out.println("4 - Search contacts by two fields");
            System.out.println("5 - Sort contacts");
            System.out.println("6 - Update existing contact");
            System.out.println("7 - Add new contact or contacts");
            System.out.println("8 - Delete existing contact or contacts");
            System.out.print("Select an option, only the number: ");

            String choice = Main.SC.nextLine().trim();

            switch (choice)
            {
                case "0":
                    System.out.println("Logging out. Goodbye, " + user.getFullName() + ".");
                    running = false;
                    break;

                case "1":
                    // Senior changes own password
                    userOps.changePassword(user.getUserId());
                    break;

                case "2":
                    // List all contacts with full details
                    contactOps.listAllContacts();
                    break;

                case "3":
                    // Single field search
                    contactOps.searchSingleField();
                    break;

                case "4":
                    // Multiple fields search
                    contactOps.searchMultipleFields();
                    break;

                case "5":
                    // Sort contacts (first name / nickname / birth date)
                    contactOps.sortContacts();
                    break;

                case "6":
                    // Update one field of an existing contact
                    contactOps.updateContactField();
                    break;

                case "7":
                    // Add new contact(s)
                    contactOps.addNewContactOrContacts();
                    break;

                case "8":
                    // Delete existing contact(s)
                    contactOps.deleteContactOrContacts();
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }

    private void showManagerMenu(User user)
    {
        boolean running = true;

        while (running)
        {
            System.out.println();
            System.out.println("=== Manager Menu ===");
            System.out.println("Logged in as: " + user.getFullName() + " (role: " + user.getRole() + ")");
            System.out.println();
            System.out.println("0 - Logout");
            System.out.println("1 - Change password");
            System.out.println("2 - Contacts statistical info");
            System.out.println("3 - List all users");
            System.out.println("4 - Update existing user");
            System.out.println("5 - Add / employ new user");
            System.out.println("6 - Delete / fire existing user");
            System.out.print("Select an option,  only the number: ");

            String choice = Main.SC.nextLine().trim();

            switch (choice)
            {
                case "0":
                    System.out.println("Logging out. Goodbye, " + user.getFullName() + ".");
                    running = false;
                    break;

                case "1":
                    // Manager changes own password
                    userOps.changePassword(user.getUserId());
                    break;

                case "2":
                    // Contacts statistical info (birth month, domains, age, LinkedIn)
                    contactOps.showContactStatistics();
                    break;

                case "3":
                    // List all users with full details
                    userOps.listAllUsers();
                    break;

                case "4":
                    // Update existing user (username, name, surname, role, password)
                    userOps.updateExistingUser();
                    break;

                case "5":
                    // Add / employ new user(s)
                    userOps.addNewUserOrUsers();
                    break;

                case "6":
                    // Delete / fire existing user(s)
                    userOps.deleteUserOrUsers();
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }
}
