package UI;

import data.Database;
import data.Operations_onUser;
import data.Operations_onContact;

import person.User;

import java.util.Scanner;

public class Main
{
    public static final Scanner SC = new Scanner(System.in);

    public static void main(String[] args)
    {
        Database database = new Database();

        Operations_onUser userOps = new Operations_onUser(database);
        Operations_onContact contactOps = new Operations_onContact(database);

        runApp(userOps, contactOps);
    }

    private static void runApp(Operations_onUser userOps, Operations_onContact contactOps)
    {
        System.out.println("=== Login Screen ===");

        User currentUser = null;

        while (currentUser == null)
        {
            System.out.print("Username: ");
            String username = SC.nextLine().trim();

            System.out.print("Password: ");
            String password = SC.nextLine().trim();

            // Real login check using Operations_onUser
            currentUser = userOps.login(username, password);

            if (currentUser == null)
            {
                System.out.println("Invalid credentials, please try again.");
            }
        }

        System.out.println("Login successful.");
        System.out.println("Welcome, " + currentUser.getFullName() +
                " (role: " + currentUser.getRole() + ").");

        MenuManager menuManager = new MenuManager(userOps, contactOps);
        menuManager.showMenuFor(currentUser);
    }
}
