package data;

import UI.Main;

import person.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

public class Operations_onUser
{
    private final Database database;

    public Operations_onUser(Database database)
    {
        this.database = database;
    }

    public User login(String username, String passwordPlain)
    {
        String hashed = PasswordUtil.hashPassword(passwordPlain);

        String sql = "SELECT user_id, username, password_hash, name, surname, role " +
                "FROM users " +
                "WHERE username = ? AND password_hash = ?";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, username);
                stmt.setString(2, hashed);

                try (ResultSet rs = stmt.executeQuery())
                {
                    if (rs.next())
                    {
                        User user = new User();
                        user.setUserId(rs.getInt("user_id"));
                        user.setUsername(rs.getString("username"));
                        user.setPasswordHash(rs.getString("password_hash"));
                        user.setName(rs.getString("name"));
                        user.setSurname(rs.getString("surname"));
                        user.setRole(rs.getString("role"));
                        return user;
                    }
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while checking login:");
            e.printStackTrace();
        }

        // No matching user or wrong password
        return null;
    }

    public void changePassword(int userId)
    {
        System.out.println();
        System.out.println("=== Change Password ===");

        String newPassword;

        // INPUT LOOP
        while (true)
        {
            System.out.print("Enter your new password: ");
            newPassword = Main.SC.nextLine().trim();

            if (newPassword.isEmpty())
            {
                System.out.println("Password cannot be empty. Please try again.");
                continue;
            }

            System.out.print("Confirm new password: ");
            String confirm = Main.SC.nextLine().trim();

            if (!newPassword.equals(confirm))
            {
                System.out.println("Passwords do not match. Please try again.");
                continue;
            }

            break; // success
        }

        // HASH IT
        String hashed = PasswordUtil.hashPassword(newPassword);

        // UPDATE SQL
        String sql = "UPDATE users SET password_hash = ?, updated_at = NOW() WHERE user_id = ?";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, hashed);
                stmt.setInt(2, userId);

                int rows = stmt.executeUpdate();

                if (rows == 1)
                {
                    System.out.println("Password updated successfully.");
                }
                else
                {
                    System.out.println("No user found with ID: " + userId + ".");
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while changing password:");
            e.printStackTrace();
        }
    }

    public void listAllUsers()
    {
        System.out.println();
        System.out.println("=== All Users ===");

        String sql = "SELECT user_id, username, password_hash, name, surname, role, " +
                "created_at, updated_at " +
                "FROM users " +
                "ORDER BY user_id";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                boolean any = false;

                while (rs.next())
                {
                    any = true;

                    int id = rs.getInt("user_id");
                    String username = rs.getString("username");
                    String passwordHash = rs.getString("password_hash");
                    String name = rs.getString("name");
                    String surname = rs.getString("surname");
                    String role = rs.getString("role");
                    String createdAt = rs.getString("created_at");
                    String updatedAt = rs.getString("updated_at");

                    System.out.println("--------------------------------");
                    System.out.println("User ID     : " + id);
                    System.out.println("Username    : " + username);
                    System.out.println("PasswordHash: " + passwordHash);
                    System.out.println("Name        : " + name);
                    System.out.println("Surname     : " + surname);
                    System.out.println("Role        : " + role);
                    System.out.println("Created At  : " + createdAt);
                    System.out.println("Updated At  : " + updatedAt);
                }

                if (!any)
                {
                    System.out.println("No users found.");
                }

                System.out.println("--------------------------------");
                System.out.println("=== End of Users ===");
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while listing all users:");
            e.printStackTrace();
        }
    }

    public void updateExistingUser()
    {
        System.out.println();
        System.out.println("=== Update Existing User ===");

        // 1) Ask for user ID
        System.out.print("Enter user ID to update: ");
        String idText = Main.SC.nextLine().trim();

        int userId;
        try
        {
            userId = Integer.parseInt(idText);
        }
        catch (NumberFormatException e)
        {
            System.out.println("Invalid user ID. Returning to previous menu.");
            return;
        }

        // 2) Show updatable fields
        System.out.println();
        System.out.println("Select the field you want to update:");
        System.out.println("1 - Username");
        System.out.println("2 - Name");
        System.out.println("3 - Surname");
        System.out.println("4 - Role");
        System.out.println("5 - Password");
        System.out.print("Your choice: ");

        String choice = Main.SC.nextLine().trim();

        String columnName;
        String fieldLabel;

        switch (choice)
        {
            case "1":
                columnName = "username";
                fieldLabel = "username";
                break;

            case "2":
                columnName = "name";
                fieldLabel = "name";
                break;

            case "3":
                columnName = "surname";
                fieldLabel = "surname";
                break;

            case "4":
                columnName = "role";
                fieldLabel = "role";
                break;

            case "5":
                columnName = "password_hash";
                fieldLabel = "password";
                break;

            default:
                System.out.println("Invalid selection. Returning to previous menu.");
                return;
        }

        // 3) Ask for new value
        System.out.print("Enter new " + fieldLabel + ": ");
        String newValue = Main.SC.nextLine().trim();

        if (newValue.isEmpty())
        {
            System.out.println("New value cannot be empty. Operation cancelled.");
            return;
        }

        // 4) Password hashing if needed
        if (choice.equals("5"))
        {
            newValue = PasswordUtil.hashPassword(newValue);
        }

        // 5) Do the update
        String sql = "UPDATE users SET " + columnName + " = ?, updated_at = NOW() " +
                "WHERE user_id = ?";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, newValue);
                stmt.setInt(2, userId);

                int rows = stmt.executeUpdate();

                if (rows == 1)
                {
                    System.out.println("User " + userId + " " + fieldLabel + " updated successfully.");
                }
                else if (rows == 0)
                {
                    System.out.println("No user found with ID " + userId + ".");
                }
                else
                {
                    System.out.println("Warning: multiple rows updated for user ID " + userId + ".");
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while updating user:");
            e.printStackTrace();
        }
    }

    public void addNewUserOrUsers()
    {
        boolean adding = true;

        while (adding)
        {
            System.out.println();
            System.out.println("=== Add New User ===");

            // 1) Username (required)
            String username;
            while (true)
            {
                System.out.print("Username: ");
                username = Main.SC.nextLine().trim();

                if (!username.isEmpty())
                    break;

                System.out.println("Username cannot be empty. Please try again.");
            }

            // 2) First name (required)
            String name;
            while (true)
            {
                System.out.print("Name: ");
                name = Main.SC.nextLine().trim();

                if (!name.isEmpty())
                    break;

                System.out.println("Name cannot be empty. Please try again.");
            }

            // 3) Surname (required)
            String surname;
            while (true)
            {
                System.out.print("Surname: ");
                surname = Main.SC.nextLine().trim();

                if (!surname.isEmpty())
                    break;

                System.out.println("Surname cannot be empty. Please try again.");
            }

            // 4) Role (required)
            String role;
            while (true)
            {
                System.out.print("Role (manager / senior / junior / tester): ");
                role = Main.SC.nextLine().trim().toLowerCase();

                if (!role.isEmpty())
                    break;

                System.out.println("Role cannot be empty. Please try again.");
            }

            // 5) Password (required → will be hashed)
            String password;
            while (true)
            {
                System.out.print("Password: ");
                password = Main.SC.nextLine().trim();

                if (!password.isEmpty())
                    break;

                System.out.println("Password cannot be empty. Please try again.");
            }

            // Hash password before storing
            String hashed = PasswordUtil.hashPassword(password);

            // 6) INSERT INTO DATABASE
            String sql = "INSERT INTO users " +
                    "(username, password_hash, name, surname, role, created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, NOW(), NOW())";

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sql))
                {
                    stmt.setString(1, username);
                    stmt.setString(2, hashed);
                    stmt.setString(3, name);
                    stmt.setString(4, surname);
                    stmt.setString(5, role);

                    int rows = stmt.executeUpdate();

                    if (rows == 1)
                    {
                        System.out.println("New user added successfully.");
                    }
                    else
                    {
                        System.out.println("Warning: unexpected number of rows inserted (" + rows + ").");
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while inserting new user:");
                e.printStackTrace();
            }

            // 7) Ask if user wants to add more
            System.out.print("Do you want to add one more user? (y/n): ");
            String again = Main.SC.nextLine().trim().toLowerCase();

            if (!again.equals("y"))
            {
                adding = false;
            }
        }

        System.out.println("Returning from Add New User.");
    }

    public void deleteUserOrUsers()
    {
        boolean deleting = true;

        while (deleting)
        {
            System.out.println();
            System.out.println("=== Delete User ===");

            // 1) Ask for user ID
            System.out.print("Enter user ID to delete: ");
            String idText = Main.SC.nextLine().trim();

            int userId;
            try
            {
                userId = Integer.parseInt(idText);
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid ID. Please enter a valid number.");
                continue;
            }

            // 2) Fetch user info (name + surname) to confirm deletion
            String sqlCheck = "SELECT name, surname FROM users WHERE user_id = ?";

            String name = null;
            String surname = null;

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sqlCheck))
                {
                    stmt.setInt(1, userId);

                    try (ResultSet rs = stmt.executeQuery())
                    {
                        if (rs.next())
                        {
                            name = rs.getString("name");
                            surname = rs.getString("surname");
                        }
                        else
                        {
                            System.out.println("No user found with that ID.");
                            continue;
                        }
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while checking user:");
                e.printStackTrace();
                continue;
            }

            // 3) Show found user info
            System.out.println("User found: " + name + " " + surname);
            System.out.print("Are you sure you want to delete this user? (y/n): ");
            String confirm = Main.SC.nextLine().trim().toLowerCase();

            if (!confirm.equals("y"))
            {
                System.out.println("Deletion cancelled.");
                continue;
            }

            // 4) Perform DELETE
            String sqlDelete = "DELETE FROM users WHERE user_id = ?";

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sqlDelete))
                {
                    stmt.setInt(1, userId);

                    int rows = stmt.executeUpdate();

                    if (rows == 1)
                    {
                        System.out.println("User " + name + " " + surname + " deleted successfully.");
                    }
                    else
                    {
                        System.out.println("Warning: No rows deleted.");
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while deleting user:");
                e.printStackTrace();
            }

            // 5) Ask if user wants to delete another
            System.out.print("Do you want to delete another user? (y/n): ");
            String again = Main.SC.nextLine().trim().toLowerCase();

            if (!again.equals("y"))
            {
                deleting = false;
            }
        }

        System.out.println("Returning from Delete User.");
    }
}