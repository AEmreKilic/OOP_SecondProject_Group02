package data;

import UI.Main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.sql.Types;


public class Operations_onContact
{
    private final Database database;

    public Operations_onContact(Database database)
    {
        this.database = database;
    }

    public void listAllContacts()
    {
        String sql = "SELECT contact_id, first_name, middle_name, last_name, nickname, " +
                "email, phone_primary, phone_secondary, linkedin_url, birth_date, " +
                "created_at, updated_at " +
                "FROM contacts " +
                "ORDER BY contact_id";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                System.out.println();
                System.out.println("=== All Contacts ===");

                boolean any = false;

                while (rs.next())
                {
                    any = true;

                    int id = rs.getInt("contact_id");

                    // Get values safely
                    String first  = rs.getString("first_name");
                    String middle = rs.getString("middle_name");
                    String last   = rs.getString("last_name");
                    String nick   = rs.getString("nickname");
                    String email  = rs.getString("email");
                    String p1     = rs.getString("phone_primary");
                    String p2     = rs.getString("phone_secondary");
                    String link   = rs.getString("linkedin_url");
                    String birth  = rs.getString("birth_date");
                    String created = rs.getString("created_at");
                    String updated = rs.getString("updated_at");

                    // Print full contact block
                    System.out.println("--------------------------------");
                    System.out.println("Contact ID     : " + id);
                    System.out.println("First Name     : " + (first  != null ? first  : "Null"));
                    System.out.println("Middle Name    : " + (middle != null ? middle : "Null"));
                    System.out.println("Last Name      : " + (last   != null ? last   : "Null"));
                    System.out.println("Nickname       : " + (nick   != null ? nick   : "Null"));
                    System.out.println("Email          : " + (email  != null ? email  : "Null"));
                    System.out.println("Phone Primary  : " + (p1     != null ? p1     : "Null"));
                    System.out.println("Phone Secondary: " + (p2     != null ? p2     : "Null"));
                    System.out.println("LinkedIn URL   : " + (link   != null ? link   : "Null"));
                    System.out.println("Birth Date     : " + (birth  != null ? birth  : "Null"));
                    System.out.println("Created At     : " + (created != null ? created : "Null"));
                    System.out.println("Updated At     : " + (updated != null ? updated : "Null"));
                }

                if (!any)
                {
                    System.out.println("No contacts found.");
                }

                System.out.println("--------------------------------");
                System.out.println("=== End of Contacts ===");
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while listing all contacts:");
            e.printStackTrace();
        }
    }

    public void searchSingleField()
    {
        System.out.println();
        System.out.println("=== Single Field Search ===");

        // 1) Field selection menu
        System.out.println("Select the field you want to search by, only the number:");
        System.out.println("1 - First name");
        System.out.println("2 - Middle name");
        System.out.println("3 - Last name");
        System.out.println("4 - Nickname");
        System.out.println("5 - Email");
        System.out.println("6 - Phone (primary)");
        System.out.println("7 - Phone (secondary)");
        System.out.println("8 - LinkedIn URL");
        System.out.println("9 - Birth date (YYYY-MM-DD)");
        System.out.print("Your choice: ");

        String choice = Main.SC.nextLine().trim();

        String column = null;
        String fieldLabel = null;
        String formatHelp = "";  // Explanation to user before input

        switch (choice)
        {
            case "1":
                column = "first_name";
                fieldLabel = "First name";
                formatHelp = "Write any part of the first name.";
                break;

            case "2":
                column = "middle_name";
                fieldLabel = "Middle name";
                formatHelp = "Write any part of the middle name.";
                break;

            case "3":
                column = "last_name";
                fieldLabel = "Last name";
                formatHelp = "Write any part of the last name.";
                break;

            case "4":
                column = "nickname";
                fieldLabel = "Nickname";
                formatHelp = "Write any part of the nickname.";
                break;

            case "5":
                column = "email";
                fieldLabel = "Email";
                formatHelp = "Must contain '@'. Write any substring.";
                break;

            case "6":
                column = "phone_primary";
                fieldLabel = "Primary phone";
                formatHelp = "Digits only. No spaces.";
                break;

            case "7":
                column = "phone_secondary";
                fieldLabel = "Secondary phone";
                formatHelp = "Digits only. No spaces.";
                break;

            case "8":
                column = "linkedin_url";
                fieldLabel = "LinkedIn URL";
                formatHelp = "Example: https://linkedin.com/... or any substring.";
                break;

            case "9":
                column = "birth_date";
                fieldLabel = "Birth date";
                formatHelp = "Must be in format YYYY-MM-DD. Example: 1999-05-20";
                break;

            default:
                System.out.println("Invalid selection. Returning to previous menu.");
                return;
        }

        // 2) Format explanation
        System.out.println("\nHow to search in this field:");
        System.out.println(formatHelp);
        System.out.print("Enter search value: ");

        String value = Main.SC.nextLine().trim();

        if (value.isEmpty())
        {
            System.out.println("Search value cannot be empty. Returning.");
            return;
        }

        // 3) Build SQL
        String sql;

        if (choice.equals("9"))  // birth_date (exact match)
        {
            sql = "SELECT * FROM contacts WHERE " + column + " = ?";
        }
        else
        {
            // LIKE search for all text fields
            sql = "SELECT * FROM contacts WHERE " + column + " LIKE ?";
            value = "%" + value + "%";
        }

        // 4) Execute query
        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, value);

                try (ResultSet rs = stmt.executeQuery())
                {
                    System.out.println();
                    System.out.println("=== Search Results (" + fieldLabel + ") ===");

                    boolean any = false;

                    while (rs.next())
                    {
                        any = true;

                        String first  = rs.getString("first_name");
                        String middle = rs.getString("middle_name");
                        String last   = rs.getString("last_name");
                        String nick   = rs.getString("nickname");
                        String email  = rs.getString("email");
                        String p1     = rs.getString("phone_primary");
                        String p2     = rs.getString("phone_secondary");
                        String link   = rs.getString("linkedin_url");
                        String birth  = rs.getString("birth_date");
                        String created = rs.getString("created_at");
                        String updated = rs.getString("updated_at");

                        System.out.println("--------------------------------");
                        System.out.println("Contact ID     : " + rs.getInt("contact_id"));
                        System.out.println("First Name     : " + (first  != null ? first  : "Null"));
                        System.out.println("Middle Name    : " + (middle != null ? middle : "Null"));
                        System.out.println("Last Name      : " + (last   != null ? last   : "Null"));
                        System.out.println("Nickname       : " + (nick   != null ? nick   : "Null"));
                        System.out.println("Email          : " + (email  != null ? email  : "Null"));
                        System.out.println("Phone Primary  : " + (p1     != null ? p1     : "Null"));
                        System.out.println("Phone Secondary: " + (p2     != null ? p2     : "Null"));
                        System.out.println("LinkedIn URL   : " + (link   != null ? link   : "Null"));
                        System.out.println("Birth Date     : " + (birth  != null ? birth  : "Null"));
                        System.out.println("Created At     : " + (created != null ? created : "Null"));
                        System.out.println("Updated At     : " + (updated != null ? updated : "Null"));
                    }
                    if (!any)
                    {
                        System.out.println("No contacts matched your search.");
                    }

                    System.out.println("--------------------------------");
                    System.out.println("=== End of Results ===");
                }
            }

        }
        catch (SQLException e)
        {
            System.err.println("Error during search:");
            e.printStackTrace();
        }
    }

    public void searchMultipleFields()
    {
        System.out.println();
        System.out.println("=== Multiple Field Search ===");

        // 1) Combo seçimi
        System.out.println("Select the field combination you want to search by, only the number:");
        System.out.println("1 - First name AND Last name");
        System.out.println("2 - Email AND Birth date (YYYY-MM-DD)");
        System.out.println("3 - Nickname AND LinkedIn URL");
        System.out.print("Your choice: ");

        String choice = Main.SC.nextLine().trim();

        String column1 = null;
        String column2 = null;
        String label1 = null;
        String label2 = null;
        String help1 = "";
        String help2 = "";
        boolean secondIsExactMatch = false;

        switch (choice)
        {
            case "1":
                column1 = "first_name";
                column2 = "last_name";
                label1 = "First name";
                label2 = "Last name";
                help1 = "Write any part of the first name.";
                help2 = "Write any part of the last name.";
                break;

            case "2":
                column1 = "email";
                column2 = "birth_date";
                label1 = "Email";
                label2 = "Birth date";
                help1 = "Must contain '@'. You can search by any substring.";
                help2 = "Use format YYYY-MM-DD. Example: 2001-03-15 (month must be 01..12).";
                secondIsExactMatch = true;
                break;

            case "3":
                column1 = "nickname";
                column2 = "linkedin_url";
                label1 = "Nickname";
                label2 = "LinkedIn URL";
                help1 = "Write any part of the nickname.";
                help2 = "You can search by any substring, e.g. 'linkedin.com/in/' or 'dar'.";
                break;

            default:
                System.out.println("Invalid selection. Returning to previous menu.");
                return;
        }

        // 2) Format açıklaması
        System.out.println();
        System.out.println("How to search in these fields:");
        System.out.println(label1 + " -> " + help1);

        // 3) İlk value (boş olamaz)
        String value1;
        while (true)
        {
            System.out.print("Enter value for " + label1 + ": ");
            value1 = Main.SC.nextLine().trim();

            if (value1.isEmpty())
            {
                System.out.println("Value cannot be empty. Please try again.");
                continue;
            }

            if (choice.equals("2") && label1.equals("Email") && !value1.contains("@"))
            {
                System.out.println("Email seems invalid (no '@'). Please try again.");
                continue;
            }

            break;
        }

        System.out.println();
        System.out.println("How to search in these fields:");
        System.out.println(label2 + " -> " + help2);

        String value2;
        while (true)
        {
            System.out.print("Enter value for " + label2 + ": ");
            value2 = Main.SC.nextLine().trim();

            if (value2.isEmpty())
            {
                System.out.println("Value cannot be empty. Please try again.");
                continue;
            }
            break;
        }

        // 5) SQL hazırlama
        String sql = "SELECT contact_id, first_name, middle_name, last_name, nickname, " +
                "email, phone_primary, phone_secondary, linkedin_url, birth_date, " +
                "created_at, updated_at " +
                "FROM contacts WHERE ";

        if (secondIsExactMatch)
        {
            // Email LIKE, Birth date exact
            sql += column1 + " LIKE ? AND " + column2 + " = ?";
            value1 = "%" + value1 + "%";
            // value2 aynen kalıyor (YYYY-MM-DD)
        }
        else
        {
            // İki alan da LIKE
            sql += column1 + " LIKE ? AND " + column2 + " LIKE ?";
            value1 = "%" + value1 + "%";
            value2 = "%" + value2 + "%";
        }

        // 6) Sorguyu çalıştırma ve sonuçları yazdırma
        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, value1);
                stmt.setString(2, value2);

                try (ResultSet rs = stmt.executeQuery())
                {
                    System.out.println();
                    System.out.println("=== Multiple Field Search Results ===");

                    boolean any = false;

                    while (rs.next())
                    {
                        any = true;

                        String first   = rs.getString("first_name");
                        String middle  = rs.getString("middle_name");
                        String last    = rs.getString("last_name");
                        String nick    = rs.getString("nickname");
                        String email   = rs.getString("email");
                        String p1      = rs.getString("phone_primary");
                        String p2      = rs.getString("phone_secondary");
                        String link    = rs.getString("linkedin_url");
                        String birth   = rs.getString("birth_date");
                        String created = rs.getString("created_at");
                        String updated = rs.getString("updated_at");

                        System.out.println("--------------------------------");
                        System.out.println("Contact ID     : " + rs.getInt("contact_id"));
                        System.out.println("First Name     : " + (first   != null ? first   : "Null"));
                        System.out.println("Middle Name    : " + (middle  != null ? middle  : "Null"));
                        System.out.println("Last Name      : " + (last    != null ? last    : "Null"));
                        System.out.println("Nickname       : " + (nick    != null ? nick    : "Null"));
                        System.out.println("Email          : " + (email   != null ? email   : "Null"));
                        System.out.println("Phone Primary  : " + (p1      != null ? p1      : "Null"));
                        System.out.println("Phone Secondary: " + (p2      != null ? p2      : "Null"));
                        System.out.println("LinkedIn URL   : " + (link    != null ? link    : "Null"));
                        System.out.println("Birth Date     : " + (birth   != null ? birth   : "Null"));
                        System.out.println("Created At     : " + (created != null ? created : "Null"));
                        System.out.println("Updated At     : " + (updated != null ? updated : "Null"));
                    }

                    if (!any)
                    {
                        System.out.println("No contacts matched your search.");
                    }

                    System.out.println("--------------------------------");
                    System.out.println("=== End of Results ===");
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error during multiple field search:");
            e.printStackTrace();
        }
    }

    public void sortContacts()
    {
        System.out.println();
        System.out.println("=== Sort Contacts ===");

        // 1) Field seçimi
        System.out.println("Select the field to sort by, only the number:");
        System.out.println("1 - First name");
        System.out.println("2 - Nickname");
        System.out.println("3 - Birth date");
        System.out.print("Your choice: ");

        String fieldChoice = Main.SC.nextLine().trim();

        String column;
        String sortLabel;

        switch (fieldChoice)
        {
            case "1":
                column = "first_name";
                sortLabel = "First name";
                break;

            case "2":
                column = "nickname";
                sortLabel = "Nickname";
                break;

            case "3":
                column = "birth_date";
                sortLabel = "Birth date";
                break;

            default:
                System.out.println("Invalid selection. Returning to previous menu.");
                return;
        }

        // 2) Sıralama yönü seçimi
        String direction;
        if (fieldChoice.equals("3"))
        {
            // Birth date özel text
            System.out.println();
            System.out.println("Select sort order for Birth date, only the number:");
            System.out.println("1 - Older to younger (oldest first)");
            System.out.println("2 - Younger to older (youngest first)");
            System.out.print("Your choice: ");

            String orderChoice = Main.SC.nextLine().trim();

            if (orderChoice.equals("1"))
            {
                direction = "ASC"; // older (smaller date) first
            }
            else if (orderChoice.equals("2"))
            {
                direction = "DESC"; // younger (bigger date) first
            }
            else
            {
                System.out.println("Invalid sort order. Returning to previous menu.");
                return;
            }
        }
        else
        {
            // First name / Nickname
            System.out.println();
            System.out.println("Select sort order,  only the number:");
            System.out.println("1 - Ascending (A to Z)");
            System.out.println("2 - Descending (Z to A)");
            System.out.print("Your choice: ");

            String orderChoice = Main.SC.nextLine().trim();

            if (orderChoice.equals("1"))
            {
                direction = "ASC";
            }
            else if (orderChoice.equals("2"))
            {
                direction = "DESC";
            }
            else
            {
                System.out.println("Invalid sort order. Returning to previous menu.");
                return;
            }
        }

        // 3) SQL hazırlama (2. kriter olarak contact_id ekleyelim, stabil sıralama için)
        String sql = "SELECT contact_id, first_name, middle_name, last_name, nickname, " +
                "email, phone_primary, phone_secondary, linkedin_url, birth_date, " +
                "created_at, updated_at " +
                "FROM contacts " +
                "ORDER BY " + column + " " + direction + ", contact_id ASC";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                System.out.println();
                System.out.println("=== Sorted Contacts (" + sortLabel + ", " + direction + ") ===");

                boolean any = false;

                while (rs.next())
                {
                    any = true;

                    String first   = rs.getString("first_name");
                    String middle  = rs.getString("middle_name");
                    String last    = rs.getString("last_name");
                    String nick    = rs.getString("nickname");
                    String email   = rs.getString("email");
                    String p1      = rs.getString("phone_primary");
                    String p2      = rs.getString("phone_secondary");
                    String link    = rs.getString("linkedin_url");
                    String birth   = rs.getString("birth_date");
                    String created = rs.getString("created_at");
                    String updated = rs.getString("updated_at");

                    System.out.println("--------------------------------");
                    System.out.println("Contact ID     : " + rs.getInt("contact_id"));
                    System.out.println("First Name     : " + (first   != null ? first   : "Null"));
                    System.out.println("Middle Name    : " + (middle  != null ? middle  : "Null"));
                    System.out.println("Last Name      : " + (last    != null ? last    : "Null"));
                    System.out.println("Nickname       : " + (nick    != null ? nick    : "Null"));
                    System.out.println("Email          : " + (email   != null ? email   : "Null"));
                    System.out.println("Phone Primary  : " + (p1      != null ? p1      : "Null"));
                    System.out.println("Phone Secondary: " + (p2      != null ? p2      : "Null"));
                    System.out.println("LinkedIn URL   : " + (link    != null ? link    : "Null"));
                    System.out.println("Birth Date     : " + (birth   != null ? birth   : "Null"));
                    System.out.println("Created At     : " + (created != null ? created : "Null"));
                    System.out.println("Updated At     : " + (updated != null ? updated : "Null"));
                }

                if (!any)
                {
                    System.out.println("No contacts found.");
                }

                System.out.println("--------------------------------");
                System.out.println("=== End of Sorted Contacts ===");
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while sorting contacts:");
            e.printStackTrace();
        }
    }

    public void updateContactField()
    {
        System.out.println();
        System.out.println("=== Update Existing Contact ===");

        // 1) Ask for contact ID
        System.out.print("Enter contact ID to update: ");
        String idText = Main.SC.nextLine().trim();

        int contactId;
        try
        {
            contactId = Integer.parseInt(idText);
        }
        catch (NumberFormatException e)
        {
            System.out.println("Invalid contact ID. Returning to previous menu.");
            return;
        }

        // 2) Show updatable fields
        System.out.println();
        System.out.println("Select the field you want to update, only the number:");
        System.out.println("1 - First name");
        System.out.println("2 - Middle name");
        System.out.println("3 - Last name");
        System.out.println("4 - Nickname");
        System.out.println("5 - Email");
        System.out.println("6 - Phone (primary)");
        System.out.println("7 - Phone (secondary)");
        System.out.println("8 - LinkedIn URL");
        System.out.println("9 - Birth date (format: YYYY-MM-DD)");
        System.out.print("Your choice: ");

        String choice = Main.SC.nextLine().trim();

        String columnName;
        String fieldLabel;

        switch (choice)
        {
            case "1":
                columnName = "first_name";
                fieldLabel = "first name";
                break;

            case "2":
                columnName = "middle_name";
                fieldLabel = "middle name";
                break;

            case "3":
                columnName = "last_name";
                fieldLabel = "last name";
                break;

            case "4":
                columnName = "nickname";
                fieldLabel = "nickname";
                break;

            case "5":
                columnName = "email";
                fieldLabel = "email";
                break;

            case "6":
                columnName = "phone_primary";
                fieldLabel = "primary phone";
                break;

            case "7":
                columnName = "phone_secondary";
                fieldLabel = "secondary phone";
                break;

            case "8":
                columnName = "linkedin_url";
                fieldLabel = "LinkedIn URL";
                break;

            case "9":
                columnName = "birth_date";
                fieldLabel = "birth date (YYYY-MM-DD)";
                break;

            default:
                System.out.println("Invalid field selection. Returning to previous menu.");
                return;
        }

        // 3) Ask for new value
        System.out.print("Enter new value for " + fieldLabel + ": ");
        String newValue = Main.SC.nextLine().trim();

        if (newValue.isEmpty())
        {
            System.out.println("New value cannot be empty. Operation cancelled.");
            return;
        }

        // 4) Execute UPDATE
        String sql = "UPDATE contacts SET " + columnName + " = ?, updated_at = NOW() " +
                "WHERE contact_id = ?";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql))
            {
                stmt.setString(1, newValue);
                stmt.setInt(2, contactId);

                int rows = stmt.executeUpdate();

                if (rows == 1)
                {
                    System.out.println("Contact " + contactId + " " + fieldLabel + " updated successfully.");
                }
                else if (rows == 0)
                {
                    System.out.println("No contact found with ID " + contactId + ". Nothing updated.");
                }
                else
                {
                    System.out.println("Warning: multiple rows updated for contact ID " + contactId + ".");
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while updating contact:");
            e.printStackTrace();
        }
    }

    public void addNewContactOrContacts()
    {
        boolean adding = true;

        while (adding)
        {
            System.out.println();
            System.out.println("=== Add New Contact ===");

            // 1) First name (required)
            String firstName;
            while (true)
            {
                System.out.print("First name: ");
                firstName = Main.SC.nextLine().trim();

                if (!firstName.isEmpty())
                {
                    break;
                }

                System.out.println("First name cannot be empty. Please try again.");
            }

            // 2) Middle name (optional)
            System.out.print("Middle name (press Enter to skip): ");
            String middleName = Main.SC.nextLine().trim();
            if (middleName.isEmpty())
            {
                middleName = null;
            }

            // 3) Last name (required)
            String lastName;
            while (true)
            {
                System.out.print("Last name: ");
                lastName = Main.SC.nextLine().trim();

                if (!lastName.isEmpty())
                {
                    break;
                }

                System.out.println("Last name cannot be empty. Please try again.");
            }

            // 4) Nickname (required)
            String nickname;
            while (true)
            {
                System.out.print("Nickname: ");
                nickname = Main.SC.nextLine().trim();

                if (!nickname.isEmpty())
                {
                    break;
                }

                System.out.println("Nickname cannot be empty. Please try again.");
            }

            // 5) Email (required, basic check)
            String email;
            while (true)
            {
                System.out.print("Email: ");
                email = Main.SC.nextLine().trim();

                if (email.isEmpty())
                {
                    System.out.println("Email cannot be empty. Please try again.");
                    continue;
                }

                if (!email.contains("@"))
                {
                    System.out.println("Email seems invalid (no '@'). Please try again.");
                    continue;
                }

                break;
            }

            // 6) Phone primary (required)
            String phonePrimary;
            while (true)
            {
                System.out.print("Primary phone: ");
                phonePrimary = Main.SC.nextLine().trim();

                if (!phonePrimary.isEmpty())
                {
                    break;
                }

                System.out.println("Primary phone cannot be empty. Please try again.");
            }

            // 7) Phone secondary (optional)
            System.out.print("Secondary phone (press Enter to skip): ");
            String phoneSecondary = Main.SC.nextLine().trim();
            if (phoneSecondary.isEmpty())
            {
                phoneSecondary = null;
            }

            // 8) LinkedIn URL (optional)
            System.out.print("LinkedIn URL (press Enter to skip): ");
            String linkedin = Main.SC.nextLine().trim();
            if (linkedin.isEmpty())
            {
                linkedin = null;
            }

            // 9) Birth date (required, format: YYYY-MM-DD)
            LocalDate birthDate;
            while (true)
            {
                System.out.print("Birth date (YYYY-MM-DD): ");
                String birthText = Main.SC.nextLine().trim();

                if (birthText.isEmpty())
                {
                    System.out.println("Birth date cannot be empty. Please try again.");
                    continue;
                }

                try
                {
                    birthDate = LocalDate.parse(birthText);
                    break;
                }
                catch (DateTimeParseException e)
                {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                }
            }

            // 10) Insert into database
            String sql = "INSERT INTO contacts " +
                    "(first_name, middle_name, last_name, nickname, email, " +
                    " phone_primary, phone_secondary, linkedin_url, birth_date, " +
                    " created_at, updated_at) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sql))
                {
                    // 1 - first_name (required)
                    stmt.setString(1, firstName);

                    // 2 - middle_name (optional)
                    if (middleName != null)
                    {
                        stmt.setString(2, middleName);
                    }
                    else
                    {
                        stmt.setNull(2, Types.VARCHAR);
                    }

                    // 3 - last_name (required)
                    stmt.setString(3, lastName);

                    // 4 - nickname (required)
                    stmt.setString(4, nickname);

                    // 5 - email (required)
                    stmt.setString(5, email);

                    // 6 - phone_primary (required)
                    stmt.setString(6, phonePrimary);

                    // 7 - phone_secondary (optional)
                    if (phoneSecondary != null)
                    {
                        stmt.setString(7, phoneSecondary);
                    }
                    else
                    {
                        stmt.setNull(7, Types.VARCHAR);
                    }

                    // 8 - linkedin_url (optional)
                    if (linkedin != null)
                    {
                        stmt.setString(8, linkedin);
                    }
                    else
                    {
                        stmt.setNull(8, Types.VARCHAR);
                    }

                    // 9 - birth_date (required)
                    stmt.setDate(9, java.sql.Date.valueOf(birthDate));

                    int rows = stmt.executeUpdate();

                    if (rows == 1)
                    {
                        System.out.println("New contact added successfully.");
                    }
                    else
                    {
                        System.out.println("Warning: unexpected number of rows inserted (" + rows + ").");
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while inserting new contact:");
                e.printStackTrace();
            }

            // 11) Ask if user wants to add another contact
            System.out.print("Do you want to add one more contact? (y/n): ");
            String again = Main.SC.nextLine().trim().toLowerCase();

            if (!again.equals("y"))
            {
                adding = false;
            }
        }

        System.out.println("Returning from Add New Contact.");
    }

    public void deleteContactOrContacts()
    {
        boolean deleting = true;

        while (deleting)
        {
            System.out.println();
            System.out.println("=== Delete Contact ===");

            // 1) CONTACT ID AL
            System.out.print("Enter contact ID to delete: ");
            String idText = Main.SC.nextLine().trim();

            int contactId;
            try
            {
                contactId = Integer.parseInt(idText);
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid ID. Please enter a valid number.");
                continue;
            }

            // 2) CONTACT VAR MI + AD SOYADINI ÇEK
            String sqlCheck = "SELECT first_name, last_name FROM contacts WHERE contact_id = ?";

            String first = null;
            String last = null;

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sqlCheck))
                {
                    stmt.setInt(1, contactId);

                    try (ResultSet rs = stmt.executeQuery())
                    {
                        if (rs.next())
                        {
                            first = rs.getString("first_name");
                            last = rs.getString("last_name");
                        }
                        else
                        {
                            System.out.println("No contact found with that ID.");
                            continue; // tekrar ID sor
                        }
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while checking contact:");
                e.printStackTrace();
                continue;
            }

            // 3) AD SOYAD GÖSTER
            System.out.println("Contact found: " + first + " " + last);
            System.out.print("Are you sure you want to delete this contact? (y/n): ");
            String confirm = Main.SC.nextLine().trim().toLowerCase();

            if (!confirm.equals("y"))
            {
                System.out.println("Deletion cancelled.");
                continue; // başka ID sor
            }

            // 4) DELETE
            String sqlDelete = "DELETE FROM contacts WHERE contact_id = ?";

            try
            {
                Connection conn = database.getConnection();

                try (PreparedStatement stmt = conn.prepareStatement(sqlDelete))
                {
                    stmt.setInt(1, contactId);

                    int rows = stmt.executeUpdate();

                    if (rows == 1)
                    {
                        System.out.println("Contact " + first + " " + last + " deleted successfully.");
                    }
                    else
                    {
                        System.out.println("Warning: No rows deleted.");
                    }
                }
            }
            catch (SQLException e)
            {
                System.err.println("Error while deleting contact:");
                e.printStackTrace();
            }

            // 5) DEVAM ETMEK İSTER Mİ?
            System.out.print("Do you want to delete another contact? (y/n): ");
            String again = Main.SC.nextLine().trim().toLowerCase();

            if (!again.equals("y"))
            {
                deleting = false;
            }
        }

        System.out.println("Returning from Delete Contact.");
    }

    public void showContactStatistics()
    {
        boolean running = true;

        while (running)
        {
            System.out.println();
            System.out.println("=== Contacts Statistical Info ===");
            System.out.println("0 - Return to previous menu");
            System.out.println("1 - Birth month distribution");
            System.out.println("2 - Email domain distribution");
            System.out.println("3 - Age distribution (desc) + youngest/oldest/average");
            System.out.println("4 - LinkedIn usage (count + percentage)");
            System.out.print("Select an option, only the number: ");

            String choice = Main.SC.nextLine().trim();

            switch (choice)
            {
                case "0":
                    System.out.println("Returning to previous menu.");
                    running = false;
                    break;

                case "1":
                    showBirthMonthDistribution();
                    break;

                case "2":
                    showEmailDomainDistribution();
                    break;

                case "3":
                    showAgeDistribution();
                    break;

                case "4":
                    showLinkedInUsage();
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }
    }

    private void showBirthMonthDistribution()
    {
        System.out.println();
        System.out.println("=== Birth Month Distribution ===");

        String sql = "SELECT MONTH(birth_date) AS month_num, COUNT(*) AS cnt " +
                "FROM contacts " +
                "WHERE birth_date IS NOT NULL " +
                "GROUP BY MONTH(birth_date)";

        int[] monthCounts = new int[13]; // 1..12 kullanılacak
        String[] monthNames = {
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
        };

        int total = 0;

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    int month = rs.getInt("month_num");
                    int cnt = rs.getInt("cnt");

                    if (month >= 1 && month <= 12)
                    {
                        monthCounts[month] = cnt;
                        total += cnt;
                    }
                }
            }

            if (total == 0)
            {
                System.out.println("No contacts with a valid birth date found.");
                return;
            }

            for (int i = 1; i <= 12; i++)
            {
                System.out.println(monthNames[i - 1] + ": " + monthCounts[i] + " contact(s)");
            }

            System.out.println("Total contacts with birth date: " + total);
        }
        catch (SQLException e)
        {
            System.err.println("Error while computing birth month distribution:");
            e.printStackTrace();
        }
    }

    private void showEmailDomainDistribution()
    {
        System.out.println();
        System.out.println("=== Email Domain Distribution ===");

        String sql = "SELECT SUBSTRING_INDEX(email, '@', -1) AS domain, COUNT(*) AS cnt " +
                "FROM contacts " +
                "WHERE email IS NOT NULL AND email LIKE '%@%' " +
                "GROUP BY domain " +
                "ORDER BY cnt DESC, domain ASC";

        int total = 0;

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                boolean any = false;

                while (rs.next())
                {
                    any = true;
                    String domain = rs.getString("domain");
                    int cnt = rs.getInt("cnt");
                    total += cnt;

                    if (domain == null || domain.isBlank())
                    {
                        domain = "(no domain)";
                    }

                    System.out.println(domain + " : " + cnt + " contact(s)");
                }

                if (!any)
                {
                    System.out.println("No valid email addresses found.");
                }
                else
                {
                    System.out.println("Total contacts with valid email: " + total);
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while computing email domain distribution:");
            e.printStackTrace();
        }
    }

    private void showAgeDistribution()
    {
        System.out.println();
        System.out.println("=== Age Distribution ===");

        String sql = "SELECT TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) AS age, " +
                "COUNT(*) AS cnt " +
                "FROM contacts " +
                "WHERE birth_date IS NOT NULL " +
                "GROUP BY age " +
                "ORDER BY age DESC";

        boolean any = false;
        int oldestAge = 0;
        int youngestAge = 0;
        long totalCount = 0L;
        long sumAges = 0L;

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    any = true;

                    int age = rs.getInt("age");
                    int cnt = rs.getInt("cnt");

                    if (totalCount == 0)
                    {
                        // first row = oldest (because DESC)
                        oldestAge = age;
                    }

                    // last seen will be youngest thanks to DESC
                    youngestAge = age;

                    totalCount += cnt;
                    sumAges += (long) age * cnt;

                    System.out.println("Age " + age + ": " + cnt + " person(s)");
                }
            }

            if (!any)
            {
                System.out.println("No contacts with a valid birth date found.");
                return;
            }

            double average = (double) sumAges / (double) totalCount;

            System.out.println();
            System.out.println("Oldest age  : " + oldestAge + " year(s)");
            System.out.println("Youngest age: " + youngestAge + " year(s)");
            System.out.printf("Average age : %.1f year(s)%n", average);
            System.out.println("Total people counted: " + totalCount);
        }
        catch (SQLException e)
        {
            System.err.println("Error while computing age distribution:");
            e.printStackTrace();
        }
    }

    private void showLinkedInUsage()
    {
        System.out.println();
        System.out.println("=== LinkedIn Usage ===");

        String sql = "SELECT COUNT(*) AS total, " +
                "SUM(CASE WHEN linkedin_url IS NOT NULL AND linkedin_url <> '' THEN 1 ELSE 0 END) AS with_linkedin " +
                "FROM contacts";

        try
        {
            Connection conn = database.getConnection();

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery())
            {
                if (rs.next())
                {
                    int total = rs.getInt("total");
                    int withLinkedIn = rs.getInt("with_linkedin");

                    if (total == 0)
                    {
                        System.out.println("No contacts in the table.");
                        return;
                    }

                    int withoutLinkedIn = total - withLinkedIn;
                    double percentage = (withLinkedIn * 100.0) / total;

                    System.out.println("Total contacts          : " + total);
                    System.out.println("With LinkedIn URL       : " + withLinkedIn);
                    System.out.println("Without LinkedIn URL    : " + withoutLinkedIn);
                    System.out.printf("LinkedIn usage ratio    : %.1f%%%n", percentage);
                }
                else
                {
                    System.out.println("No contacts in the table.");
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("Error while computing LinkedIn usage:");
            e.printStackTrace();
        }
    }
}
